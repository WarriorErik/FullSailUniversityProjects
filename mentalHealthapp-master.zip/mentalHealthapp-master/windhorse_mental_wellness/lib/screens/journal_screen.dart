import 'package:flutter/material.dart';

class JournalScreen extends StatefulWidget {
  @override
  _JournalScreenState createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  final TextEditingController _entryController = TextEditingController();
  final List<Map<String, dynamic>> _journalEntries = [];
  final String dailyQuote = "Believe you can and you're halfway there.";

  // For mood selection
  String currentMood = 'Happy';
  final List<String> moodOptions = ['Happy', 'Sad', 'Excited', 'Anxious'];

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Journal', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.purple,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Text(dailyQuote, style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blue)),
            SizedBox(height: 20),
            DropdownButton<String>(
              value: currentMood,
              icon: Icon(Icons.arrow_downward),
              iconSize: 24,
              elevation: 16,
              style: TextStyle(color: Colors.deepPurple),
              underline: Container(
                height: 2,
                color: Colors.deepPurpleAccent,
              ),
              onChanged: (String? newValue) {
                setState(() {
                  currentMood = newValue!;
                });
              },
              items: moodOptions.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _entryController,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.grey[200],
                labelText: 'Write your thoughts',
                labelStyle: TextStyle(color: Colors.purple),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: Colors.purple),
              onPressed: () {
                if (_entryController.text.isNotEmpty) {
                  setState(() {
                    _journalEntries.add({
                      'mood': currentMood,
                      'entry': _entryController.text,
                      'date': DateTime.now()
                    });
                    _entryController.clear();
                  });
                }
              },
              child: Text('Add Entry', style: TextStyle(color: Colors.white)),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _journalEntries.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text('${_journalEntries[index]['entry']}'),
                    subtitle: Text('Mood: ${_journalEntries[index]['mood']}\n'
                                  'Date: ${_journalEntries[index]['date'].toLocal().toString().split(' ')[0]}'),
                    tileColor: Colors.purple[50],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
