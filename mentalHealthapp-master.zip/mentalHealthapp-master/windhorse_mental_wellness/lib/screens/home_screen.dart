import 'package:flutter/material.dart';
import 'package:windhorse_mental_wellness/screens/survey_screen.dart';
import 'package:windhorse_mental_wellness/screens/progress_tracker.dart';
import 'package:windhorse_mental_wellness/screens/journal_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Solution Focused Brief Therapy App'),
        backgroundColor: Colors.purple,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.purple, Colors.blue],
          ),
        ),
        child: Center(
          child: GridView.count(
            crossAxisCount: 2,
            childAspectRatio: MediaQuery.of(context).size.width /
                (MediaQuery.of(context).size.height / 2.2),
            children: <Widget>[
              _buildMenuButton(context, 'Start the Survey', SurveyScreen(), Colors.orange),
              _buildMenuButton(context, 'Check your Progress', ProgressTracker(), Colors.green),
              _buildMenuButton(context, 'Open the Journal', JournalScreen(), Colors.red),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMenuButton(BuildContext context, String title, Widget page, Color color) {
    return Container(
      margin: const EdgeInsets.all(15.0),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: color,
          padding: EdgeInsets.all(10.0), // Reduced the padding to make button smaller
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
        ),
        child: Text(title, style: TextStyle(color: Colors.white, fontSize: 18)), // Reduced the font size
        onPressed: () {
          Navigator.push(
            context,
            PageRouteBuilder(
              transitionDuration: Duration(seconds: 1),
              transitionsBuilder: (context, animation, animationTime, child) {
                animation = CurvedAnimation(parent: animation, curve: Curves.elasticInOut);
                return ScaleTransition(
                  scale: animation,
                  child: child,
                  alignment: Alignment.center,
                );
              },
              pageBuilder: (context, animation, animationTime) {
                return page;
              }
            ),
          );
        },
      ),
    );
  }
}
