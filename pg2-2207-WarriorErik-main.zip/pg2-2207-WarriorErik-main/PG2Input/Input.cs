﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PG2Input
{
    public static class Input
    {

		//for the menu, enter your choice twice, each individual time pressing enter, and it will take you to your choice


       public static int ReadInteger(string prompt, int min, int max)
       {



			int Number = 0;

			prompt = "Enter the integer number of your choice: ";
			
				

					//showing the prompt and asking for user input
					


					string userInput = Console.ReadLine();


					//  reading the user's input &  converting to an integer & checking if the integer is within the min-max range



					bool isTrue = int.TryParse(userInput, out Number);
					if (isTrue)
					{

				       Console.WriteLine($"Enter the number one more time and press enter again and you will see your choice displayed, {Number}");

						return Number;


					}

                    else
                    {


					Console.WriteLine("That was not an integer value, try again.");
						
                    }



                while (isTrue)
                {


				if (Number >= min && Number <= max)
				{


					return Number;


				}

				else
				{

					Console.WriteLine("The number was not within the min-max range. Try again");
					break;

				}



			    }

					
				

		 		return Number;


		}






		 public static void ReadString(string prompt, ref string value)
         {

			prompt = "Enter a string you think may be in the speech: ";

			

				while (true)
				{
					
				
				
				
				Console.WriteLine(prompt);

					
				string testString = Console.ReadLine();


					if (String.IsNullOrEmpty(testString) || String.IsNullOrWhiteSpace(testString))
					{
																											
					Console.WriteLine("Not a String! Please Try Again!");


					}
					else
					
				    {
						
					 
					 value = testString;

					 break;


						
					}
				}


	     }




		public static void ReadChoice(string prompt, string[] options, out int selection)
        {
			prompt = "Select an integer numerical choice from this list of options: ";

			Console.WriteLine(prompt);



			for(int i = 0; i < options.Length; i++)
            {

				Console.WriteLine(options[i]);


            }


			selection = ReadInteger(prompt, 0, options.Length);

			return;



        }







    }
}
