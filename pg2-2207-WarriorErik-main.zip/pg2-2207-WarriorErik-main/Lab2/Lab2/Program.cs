﻿using System;
using PG2Input;

namespace Lab2
{
    //
    //------------To run your lab code-------------
    // make sure Lab2 is the "Startup Project" (the name, Lab2, should be bold in Solution Explorer)
    // Right click the Lab2 project and select "Set as startup project"
    //
    //
    //------------To run your lecture code-------------
    // right-click the LectureCode project and select "Set as startup project"
    //      NOTE: the lecture code is NOT required for turning in the lab.
    //


    //
    //------------Lab Notes-------------
    //      Add your Sorting and Searching methods to the PG2Sorting.cs file.
    //      Add any other methods in this file.
    //      Add the menu code to the Main method.
    //

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
