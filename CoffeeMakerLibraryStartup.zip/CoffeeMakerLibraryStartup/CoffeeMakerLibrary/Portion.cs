﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeMakerLibrary
{
    public static class Portion 
    {
        public const int Short = 1;
        public const int Tall = 2;
        public const int Grande = 3;
        public const int Venti = 4;
        public const int Trenti = 5;
    }
}
