﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LectureCode
{
    public static class Lectures
    {
        static void Main(string[] args)
        {
            Day1.Run();
            Day2.Run();
            Day3.Run();
        }
    }
}
