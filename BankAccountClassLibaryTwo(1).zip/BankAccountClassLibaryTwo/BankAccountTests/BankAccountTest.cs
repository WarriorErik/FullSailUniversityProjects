﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using BankAccountClassLibaryTwo;

namespace BankAccountTests
{
    [TestClass]
    public class BankAccountTest
    {
        


        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]//Assert not needed

        public void BalanceBecomesLessThanZeroThrowsArgumentOutOfRangeException()
        {
            //Arrange or set things up 
            BankAccount accountOne = new BankAccount();

            //Act 
            accountOne.Credit(50);
            accountOne.Debit(60);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]//Assert not needed
        public void BalanceBecomesGreaterThan100000ThrowsArgumentOutOfRangeException()
        {
            //Arrange or set things up 
            BankAccount accountTwo = new BankAccount();

            //Act 
            accountTwo.Credit(100001);
        }

        [TestMethod]
        public void CreditWithValidArgumentIncreasesBalanceReturnsTrue()
        {

            //Arrange or set things up
            BankAccount accountThree = new BankAccount();

            //Act 
            bool result = accountThree.Credit(50);

            //Assert
            Assert.IsTrue(result);
            Assert.AreEqual(50, accountThree.Balance);
        }

        [TestMethod]
        public void DebitWithValidArgumentDecreasesBalanceReturnsTrue()
        {
            //Arrange or set things up
            BankAccount accountFour = new BankAccount();

            //Act
            accountFour.Credit(100);
            bool result = accountFour.Debit(50);

            //Assert
            Assert.IsTrue(result);
            Assert.AreEqual(50, accountFour.Balance);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]//Assert not needed for negative tests (sometimes)
        public void CreditWithNonPositiveArgumentThrowsArgumentOutOfRangeException()
        {
            //Arrange or set things up
            BankAccount accountFive = new BankAccount();

            //Act
            accountFive.Credit(-1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]//Assert not needed for negative tests (sometimes)
        public void DebitWithNonPositiveArgumentThrowsArgumentOutOfRangeException()
        {

            //Arrange or set things up
            BankAccount accountSix = new BankAccount();

            //Act
            accountSix.Credit(100);
            accountSix.Debit(-1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]//Assert not needed for negative tests (sometimes)
        public void CreditWithAmountGreaterThan10000ThrowsArgumentOutOfRangeException()
        {
            //Arrange or set things up
            BankAccount accountSeven = new BankAccount();

            //Act
            accountSeven.Credit(10001);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]//Assert not needed for negative tests (sometimes)
        public void DebitWithAmountGreaterThan10000ThrowsArgumentOutOfRangeException()
        {

            //Arrange or set things up
            BankAccount accountEight = new BankAccount();

            //Act
            accountEight.Credit(15000);
            accountEight.Debit(10001);
        }

        [TestMethod]
        public void FrozenAccountCannotBeCredited()
        {

            //Arrange or set things up
            BankAccount accountNine = new BankAccount();

            //Act
            accountNine.Frozen = true;
            bool result = accountNine.Credit(50);

            //Assert
            Assert.IsFalse(result);
            Assert.AreEqual(0, accountNine.Balance);
        }

        [TestMethod]
        public void FrozenAccountCannotBeDebited()
        {

            //Arrange or set things up
            BankAccount accountTen = new BankAccount();

            //Act
            accountTen.Credit(100);
            accountTen.Frozen = true;
            bool result = accountTen.Debit(50);

            //Assert
            Assert.IsFalse(result);
            Assert.AreEqual(100, accountTen.Balance);
        }
























    }
}
