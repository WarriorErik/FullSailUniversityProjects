import 'package:flutter/material.dart';

class ProgressTracker extends StatefulWidget {
  @override
  _ProgressTrackerState createState() => _ProgressTrackerState();
}

class _ProgressTrackerState extends State<ProgressTracker> {
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();
  List<Map<String, dynamic>> progressEntries = [
    {'date': DateTime.now(), 'mood': 5.0, 'notes': 'Had a great day!'},
    // Add initial entries here if needed.
  ];

  final List<String> motivationalTips = [
    "Remember, every setback is a setup for a comeback!",
    "Focus on the journey, not the destination.",
    "You are doing the best you can!",
    "Remember to take care of yourself. You can't pour from an empty cup."
  ];

  void _addEntry() {
    setState(() {
      progressEntries.insert(0, {
        'date': DateTime.now(),
        'mood': 5.0,
        'notes': '',
      });
    });
    _listKey.currentState?.insertItem(0);
  }

  Widget _buildItem(BuildContext context, Map<String, dynamic> item, Animation<double> animation) {
    return SlideTransition(
      position: Tween<Offset>(
        begin: const Offset(-1, 0),
        end: Offset(0, 0),
      ).animate(animation),
      child: Card(
        color: Colors.purple[50],
        child: ListTile(
          title: Text('${item['date']}: Mood Score ${item['mood'].toStringAsFixed(1)}'),
          subtitle: Column(
            children: [
              Text('0 is the worst, 10 is the best emotional state.', style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
              Slider(
                activeColor: Color.lerp(Colors.red, Colors.green, item['mood'] / 10.0),
                min: 0,
                max: 10,
                divisions: 10,
                label: '${item['mood'].toStringAsFixed(1)}',
                value: item['mood'],
                onChanged: (double newValue) {
                  setState(() {
                    item['mood'] = newValue;
                  });
                  if (newValue < 5) {
                    _showMotivationalTip();
                  }
                },
              ),
              if(item['mood'] < 5)
                Text(
                  '${motivationalTips[DateTime.now().millisecondsSinceEpoch % motivationalTips.length]}',
                  style: TextStyle(color: Colors.orange, fontStyle: FontStyle.italic),
                ),
            ],
          ),
          trailing: IconButton(
            icon: Icon(Icons.delete),
            onPressed: () {
              _removeItem(item);
            },
          ),
        ),
      ),
    );
  }

  void _removeItem(Map<String, dynamic> item) {
    AnimatedListRemovedItemBuilder builder = (context, animation) {
      return _buildItem(context, item, animation);
    };
    int index = progressEntries.indexOf(item);
    _listKey.currentState?.removeItem(index, builder);
    setState(() {
      progressEntries.removeAt(index);
    });
  }

  void _showMotivationalTip() {
    final tip = motivationalTips[DateTime.now().millisecondsSinceEpoch % motivationalTips.length];
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(tip),
        duration: Duration(seconds: 5),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Progress Tracker'),
        backgroundColor: Colors.purple, // Custom color for the AppBar
      ),
      body: AnimatedList(
        key: _listKey,
        initialItemCount: progressEntries.length,
        itemBuilder: (context, index, animation) {
          return _buildItem(context, progressEntries[index], animation);
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: _addEntry,
      ),
    );
  }
}
