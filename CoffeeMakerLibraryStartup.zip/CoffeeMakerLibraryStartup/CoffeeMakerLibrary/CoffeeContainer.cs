﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeMakerLibrary
{
    public class CoffeeContainer: IContainer
    {
        private bool isClean;
        private int volume;
        private const int maxVolume = 10;

        public int GetVolume()
        {
            return volume;
        }

        public void SetVolume(int volume)
        {
            this.volume = volume;
        }

        public void DispensePortion(int portion)
        {
            if (volume < portion)
            {
                throw new InvalidOperationException("Not enough coffee to dispense.");
            }
            volume -= portion;
        }

        public void Empty()
        {
            volume = 0;
        }

        public void Fill()
        {
            volume = maxVolume;
        }

        public bool IsEmpty
        {
            get { return volume == 0; }
        }

        public bool IsClean
        {
            get { return isClean; }
        }

        public void Clean()
        {
            isClean = true;
        }




    }
}
