#include "stdafx.h"
#include "Game.h"
#include <vector>
using std::cout;
using std::endl;


bool won = false;
bool lost = false;

Game::Game()
{

	Reset();
}

void Game::Reset()
{

	Console::SetWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	Console::CursorVisible(false);
	paddle.width = 12;
	paddle.height = 2;
	paddle.x_position = 32;
	paddle.y_position = 30;

	ball.visage = 'O';
	ball.color = ConsoleColor::Cyan;
	ResetBall();

	// TODO #2 - Add this brick and 4 more bricks to the vector

	Box brick;
	brick.width = 10;
	brick.height = 2;
	brick.x_position = 0;
	brick.y_position = 5;
	brick.doubleThick = true;
	brick.color = ConsoleColor::DarkGreen;

	Bricks.push_back(brick);



	brick.width = 10;
	brick.height = 2;
	brick.x_position = 0.4 * WINDOW_WIDTH;
	brick.y_position = 5;
	brick.doubleThick = true;
	brick.color = ConsoleColor::DarkGreen;
	Bricks.push_back(brick);


	brick.width = 10;
	brick.height = 2;
	brick.x_position = 0.8 * WINDOW_WIDTH;
	brick.y_position = 5;
	brick.doubleThick = true;
	brick.color = ConsoleColor::DarkGreen;
	Bricks.push_back(brick);


	brick.width = 10;
	brick.height = 2;
	brick.x_position = 1.2 * WINDOW_WIDTH;
	brick.y_position = 5;
	brick.doubleThick = true;
	brick.color = ConsoleColor::DarkGreen;
	Bricks.push_back(brick);


	brick.width = 10;
	brick.height = 2;
	brick.x_position = 1.6 * WINDOW_WIDTH;
	brick.y_position = 5;
	brick.doubleThick = true;
	brick.color = ConsoleColor::DarkGreen;
	Bricks.push_back(brick);
}

void Game::ResetBall()
{
	ball.x_position = paddle.x_position + paddle.width / 2;
	ball.y_position = paddle.y_position - 1;
	ball.x_velocity = rand() % 2 ? 1 : -1;
	ball.y_velocity = -1;
	ball.moving = false;
}

bool Game::Update()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 0x1)
		return false;

	if (GetAsyncKeyState(VK_RIGHT) && paddle.x_position < WINDOW_WIDTH - paddle.width)
		paddle.x_position += 2;

	if (GetAsyncKeyState(VK_LEFT) && paddle.x_position > 0)
		paddle.x_position -= 2;

	if (GetAsyncKeyState(VK_SPACE) & 0x1)
		ball.moving = !ball.moving;

	if (GetAsyncKeyState('R') & 0x1)
		Reset();

	ball.Update();
	CheckCollision();
	return true;
}

//  All rendering should be done between the locks in this function
void Game::Render() const
{
	Console::Lock(true);
	Console::Clear();

	paddle.Draw();
	ball.Draw();

	// TODO #3 - Update render to render all bricks

	int nums = 0;

	do
	{
		Bricks[nums].Draw();
		++nums;


	} while (nums < Bricks.size());



	while (won)
	{
		int xPos = static_cast<int>(0.2 * (80 - WINDOW_WIDTH));
		int yPos = static_cast<int>(0.2 * WINDOW_HEIGHT);
		Console::SetCursorPosition(xPos, yPos);

		won = false;
	}
	while (lost)
	{
		int xPos = static_cast<int>(0.2 * (80 - WINDOW_WIDTH));
		int yPos = static_cast<int>(0.2 * WINDOW_HEIGHT);
		Console::SetCursorPosition(xPos, yPos);


		lost = false;
	}

	Console::Lock(false);
}

void Game::CheckCollision()
{
	int nums = 0;

	while (nums < Bricks.size())
	{

		// TODO #4 - Update collision to check all bricks
		if (Bricks[nums].Contains(ball.x_position + ball.x_velocity, ball.y_position + ball.y_velocity))
		{
			Bricks[nums].color = ConsoleColor(Bricks[nums].color - 1);
			ball.y_velocity *= -1;

			// TODO #5 - If the ball hits the same brick 3 times (color == black), remove it from the vector
			if (Bricks[nums].color == Black)
			{
				auto it = Bricks.begin();
				Bricks.erase(it + nums);

			}
		}

		++nums;
	}



	// TODO #6 - If no bricks remain, pause ball and display victory text with R to reset
	while (Bricks.empty())
	{
		ball.moving = false;
		won = true;
		cout << "You Win! Press R to play again." << endl;
	}

	if (paddle.Contains(ball.x_position + ball.x_velocity, ball.y_velocity + ball.y_position))
	{
		ball.y_velocity *= -1;
	}

	// TODO #7 - If ball touches bottom of window, pause ball and display defeat text with R to reset
	while (ball.y_position > WINDOW_HEIGHT)
	{
		ball.moving = false;
		lost = true;
		cout << "You lost! Press R to play again." << endl;
	}
}
