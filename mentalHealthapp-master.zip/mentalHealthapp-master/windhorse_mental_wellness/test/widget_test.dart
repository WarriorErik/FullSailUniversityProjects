// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:windhorse_mental_wellness/main.dart';

void main() {
  testWidgets('Go through all questions by tapping Yes', (WidgetTester tester) async {
    await tester.pumpWidget(MyApp());

    final List<String> questions = [
      'Question 1: Do you often feel down, depressed, or hopeless? ',
      'Question 2: Do you have little interest or pleasure in doing things?',
      'Question 3: Do you often feel tired or have little energy?',
      'Question 4: Do you often have trouble falling asleep, staying asleep, or sleeping too much?',
      'Question 5: Do you often have poor appetite or overeat?',
      'Question 6: Do you often feel bad about yourself, or that you are a failure or have let yourself or your family down?',
      'Question 7: Do you often have trouble concentrating on things, such as reading or watching television?',
    ];

    for (int i = 0; i < questions.length - 1; i++) {
      expect(find.text(questions[i]), findsOneWidget);

      await tester.tap(find.widgetWithText(ElevatedButton, 'Yes'));
      await tester.pump();
    }

    // Last question
    expect(find.text(questions.last), findsOneWidget);
  });
}
