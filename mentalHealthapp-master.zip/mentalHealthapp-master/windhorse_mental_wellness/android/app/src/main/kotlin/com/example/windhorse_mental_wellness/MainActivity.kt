package com.example.windhorse_mental_wellness

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
