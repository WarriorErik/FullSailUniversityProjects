#first problem

def rot13(text):
    result = ""

    for c in text:
        ascii_val = ord(c)
        if c.isalpha():
            ascii_shift = 65 if c.isupper() else 97
            result += chr((ascii_val - ascii_shift + 13) % 26 + ascii_shift)
        else:
            result += c

    return result


encrypted_text = rot13("Hello, World!")
print(encrypted_text)  

decrypted_text = rot13(encrypted_text)
print(decrypted_text) 

#second problem
import random

def guess_game():
    name = input("Please enter your name: ")
    number_to_guess = random.randint(1, 20)
    guess = None

    while guess != number_to_guess:
        guess = int(input("Guess a number between 1 and 20: "))
        if guess < number_to_guess:
            print("Too low!")
        elif guess > number_to_guess:
            print("Too high!")

    print(f"Congratulations, {name}! You guessed the number.")


guess_game()

#3rd problem

from collections import Counter

def build_frequency_table(filename):
    with open(filename, 'r') as file:
        data = file.read()
        frequency_table = Counter(data)
    return frequency_table


relative_path = 'data\dict.txt'  
frequency_table = build_frequency_table(relative_path)
print(frequency_table)


#4th problem 
from collections import defaultdict

def find_anagrams(filename):
    anagrams = defaultdict(list)

    with open(filename, 'r') as file:
        for line in file:
            word = line.strip()
            sorted_word_tuple = tuple(sorted(word))
            anagrams[sorted_word_tuple].append(word)

    max_anagrams = max(anagrams.values(), key=len)
    return anagrams, max_anagrams, len(max_anagrams)


relative_path = 'data\dict.txt'  
anagrams, max_anagrams, size = find_anagrams(relative_path)

print(f"The words with the most anagrams are: {max_anagrams}")
print(f"The size of this group is: {size}")





