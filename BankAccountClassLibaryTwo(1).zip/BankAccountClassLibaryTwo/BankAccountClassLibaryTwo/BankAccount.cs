﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountClassLibaryTwo
{
    public class BankAccount
    {

        public float Balance { get; private set; }
        public bool Frozen { get; set; }

        public bool Credit(float amount)
        {
            if (Frozen) return false;

            if (amount <= 0 || amount >= 10000)
                throw new ArgumentOutOfRangeException(nameof(amount), "Amount must be greater than 0 and less than 10,000.");

            if (Balance + amount > 100000)
                throw new ArgumentOutOfRangeException(nameof(Balance), "Balance cannot be greater than 100,000.");

            Balance += amount;
            return true;
        }

        public bool Debit(float amount)
        {
            if (Frozen) return false;

            if (amount <= 0 || amount >= 10000)
                throw new ArgumentOutOfRangeException(nameof(amount), "Amount must be greater than 0 and less than 10,000.");

            if (Balance - amount < 0)
                throw new ArgumentOutOfRangeException(nameof(Balance), "Balance cannot be less than 0.");

            Balance -= amount;
            return true;
        }


    }
}
