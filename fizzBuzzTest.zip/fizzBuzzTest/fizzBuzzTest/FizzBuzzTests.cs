using FizzBuzzLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace fizzBuzzTest
{
    [TestClass]
    public class FizzBuzzTests
    {
        [DataTestMethod] // Negative tests for when the length parameter is outside the valid range
        [DataRow(-1)]
        [DataRow(0)]
        [DataRow(101)]
        public void TestValidRangeForLength(int length)
        {
            FizzBuzz fB = new FizzBuzz();
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => fB.Process(length));
        }

        [TestMethod] 

        [DataTestMethod] //10 positive tests to check if the correct string is returned
        [DataRow(1, "1")]
        [DataRow(2, "1, 2")]
        [DataRow(3, "1, 2, Fizz")]
        [DataRow(4, "1, 2, Fizz, 4")]
        [DataRow(5, "1, 2, Fizz, 4, Buzz")]
        [DataRow(6, "1, 2, Fizz, 4, Buzz, Fizz")]
        [DataRow(7, "1, 2, Fizz, 4, Buzz, Fizz, 7")]
        [DataRow(8, "1, 2, Fizz, 4, Buzz, Fizz, 7, 8")]
        [DataRow(9, "1, 2, Fizz, 4, Buzz, Fizz, 7, 8, Fizz")]
        [DataRow(10, "1, 2, Fizz, 4, Buzz, Fizz, 7, 8, Fizz, Buzz")]
        public void TestCorrectStringWithDefaultConstructor(int length, string expectedResult)
        {
            //Arrange or set things up
            FizzBuzz fBOne = new FizzBuzz();

            //Act or do something
            string resultOne = fBOne.Process(length);

            //Assert or analyze results
            Assert.AreEqual(expectedResult, resultOne);
        }

        [TestMethod] //test to eheck if correct string is returned for length parameter of 30
        public void TestLength30WithDefaultConstructor()
        {
            //Arrange or set things up
            FizzBuzz fBTwo = new FizzBuzz();

            //Act or do something
            string resultTwo = fBTwo.Process(30);
            string expectedResultTwo = "1, 2, Fizz, 4, Buzz, Fizz, 7, 8, Fizz, Buzz, 11, Fizz, 13, 14, FizzBuzz, 16, 17, Fizz, 19, Buzz, Fizz, 22, 23, Fizz, Buzz, 26, Fizz, 28, 29, FizzBuzz";

            //Assert or analyze results
            Assert.AreEqual(expectedResultTwo, resultTwo);
        }

        [TestMethod] //test to eheck if correct string is returned for length parameter of 50
        public void TestLength50WithDefaultConstructor()
        {
            //Arrange or set things up
            FizzBuzz fBThree = new FizzBuzz();

            //Act or do something
            string resultThree = fBThree.Process(50);
            string expectedResultThree = "1, 2, Fizz, 4, Buzz, Fizz, 7, 8, Fizz, Buzz, 11, Fizz, 13, 14, FizzBuzz, 16, 17, Fizz, 19, Buzz, Fizz, 22, 23, Fizz, Buzz, 26, Fizz, 28, 29, FizzBuzz, 31, 32, Fizz, 34, Buzz, Fizz, 37, 38, Fizz, Buzz, 41, Fizz, 43, 44, FizzBuzz, 46, 47, Fizz, 49, Buzz";

            //Assert or analyze results
            Assert.AreEqual(expectedResultThree, resultThree);
        }

        [TestMethod] //test to eheck if correct string is returned for length parameter of 100
        public void TestLength100WithDefaultConstructor()
        {
            //Arrange or set things up
            FizzBuzz fBFour = new FizzBuzz();

            //Act or do something
            string resultFour = fBFour.Process(100);
            string expectedResultFour = "1, 2, Fizz, 4, Buzz, Fizz, 7, 8, Fizz, Buzz, 11, Fizz, 13, 14, FizzBuzz, 16, 17, Fizz, 19, Buzz, Fizz, 22, 23, Fizz, Buzz, 26, Fizz, 28, 29, FizzBuzz, 31, 32, Fizz, 34, Buzz, Fizz, 37, 38, Fizz, Buzz, 41, Fizz, 43, 44, FizzBuzz, 46, 47, Fizz, 49, Buzz, Fizz, 52, 53, Fizz, Buzz, 56, Fizz, 58, 59, FizzBuzz, 61, 62, Fizz, 64, Buzz, Fizz, 67, 68, Fizz, Buzz, 71, Fizz, 73, 74, FizzBuzz, 76, 77, Fizz, 79, Buzz, Fizz, 82, 83, Fizz, Buzz, 86, Fizz, 88, 89, FizzBuzz, 91, 92, Fizz, 94, Buzz, Fizz, 97, 98, Fizz, Buzz";

            //Assert or analyze results
            Assert.AreEqual(expectedResultFour, resultFour); 
        }


        [DataTestMethod]  // Test to ensure the correct string is returned when using a non-default constructor with custom fizz and buzz values and strings
        [DataRow(2, "Hello", 3, "World", 6, "1, Hello, World, Hello, 5, HelloWorld")]
        [DataRow(4, "Fizz", 6, "Buzz", 12, "1, 2, 3, Fizz, 5, Buzz, Fizz, 8, 9, FizzBuzz, 11, Buzz")]
        public void TestNonDefaultConstructor(int fizzValue, string fizzString, int buzzValue, string buzzString, int length, string expectedResultFive)
        {
            //Arrange or set things up
            FizzBuzz fBFive = new FizzBuzz(fizzValue, fizzString, buzzValue, buzzString);

            //Act or do something
            string resultFive = fBFive.Process(length);

            //Assert or analyze results
            Assert.AreEqual(expectedResultFive, resultFive);
        }



    }
}