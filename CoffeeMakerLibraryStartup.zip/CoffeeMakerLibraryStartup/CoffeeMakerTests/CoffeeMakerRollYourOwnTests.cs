﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CoffeeMakerLibrary;

namespace CoffeeMakerTests
{
    [TestClass]
    public class CoffeeMakerRollYourOwnTests
    {

        [TestMethod]
        public void RYOTest1()
        {
            // ARRANGE
            IContainer waterContainer = new WaterContainer();
            IContainer coffeeContainer = new CoffeeContainer();
            ICoffeeMaker coffeeMaker = new CoffeeMaker(waterContainer, coffeeContainer);

            // Call Fill() to fill the coffee maker.
            coffeeMaker.Fill();

            // ACT
            // Call MakeCoffee() requesting a Grande(3).
            coffeeMaker.MakeCoffee(Portion.Grande);

            // ASSERT
            // Assert that the coffee volume is now 7 using the CoffeeVolume property.
            // Assert that the water volume is now 7 using the WaterVolume property.
            Assert.AreEqual(7, coffeeMaker.CoffeeVolume);
            Assert.AreEqual(7, coffeeMaker.WaterVolume);
        }

        [TestMethod]
        public void RYOTest2()
        {
            // ARRANGE
            IContainer waterContainer = new WaterContainer();
            IContainer coffeeContainer = new CoffeeContainer();
            ICoffeeMaker coffeeMaker = new CoffeeMaker(waterContainer, coffeeContainer);

            // Set the coffee to 8 using the CoffeeVolume property.
            coffeeMaker.CoffeeVolume = 8;

            // Set the water to 6 using the WaterVolume property.
            coffeeMaker.WaterVolume = 6;

            // ACT 
            // MakeCoffee() requesting a Tall(2).
            coffeeMaker.MakeCoffee(Portion.Tall);

            // ASSERT

            // Assert that the coffee volume is now 6 using the CoffeeVolume property.
            Assert.AreEqual(6, coffeeMaker.CoffeeVolume);

            // Assert that the water volume is now 4 using the WaterVolume property.
            Assert.AreEqual(4, coffeeMaker.WaterVolume);
        }

        [TestMethod]
        public void RYOTest3()
        {
            // ARRANGE
            IContainer waterContainer = new WaterContainer();
            IContainer coffeeContainer = new CoffeeContainer();
            ICoffeeMaker coffeeMaker = new CoffeeMaker(waterContainer, coffeeContainer);

            // Set the coffee to 5 using the CoffeeVolume property.
            coffeeMaker.CoffeeVolume = 5;

            // Set the water to 5 using the WaterVolume property. 
            coffeeMaker.WaterVolume = 5;

            // ACT
            // Clean() the coffee maker.
            coffeeMaker.Clean();

            // ASSERT
            // Assert that the coffee volume is now 0 using the IsEmpty property.
            Assert.IsTrue(coffeeMaker.IsEmpty);
        }

        [TestMethod]
        public void RYOTest4()
        {
            // ARRANGE
            IContainer waterContainer = new WaterContainer();
            IContainer coffeeContainer = new CoffeeContainer();
            ICoffeeMaker coffeeMaker = new CoffeeMaker(waterContainer, coffeeContainer);

            // Set the water to 2 using the WaterVolume property. 
            waterContainer.SetVolume(2);

            // Set the coffee to 4 using the CoffeeVolume property.
            coffeeContainer.SetVolume(4);

            // ACT & ASSERT
            Assert.ThrowsException<InvalidOperationException>(() => coffeeMaker.MakeCoffee(Portion.Grande), "Not enough water to dispense.");
        }
    }

}
