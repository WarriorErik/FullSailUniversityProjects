using CopierDLL;
using Moq;

namespace CopierTests
{
    [TestClass]
    public class copierTests
    {
        [TestMethod]
        public void Copy_EmptyString_CopiesNewline()
        {
            // Arrange
            var sourceMock = new Mock<ISource>();
            var destinationMock = new Mock<IDestination>();

            sourceMock.SetupSequence(x => x.GetChar())
                .Returns('\n');

            Copier copier = new Copier(destinationMock.Object, sourceMock.Object);

            // Act
            copier.Copy();

            // Assert
            destinationMock.Verify(x => x.SetChar(It.IsAny<char>()), Times.Never);

        }


        [TestMethod] 
        [DataRow("a")]// test for copies a string with 1 char
        [DataRow("ab")]//test for copies a string with 2 char
        [DataRow("abc")]// test forcopies a string with 3 char
        public void Copy_NonEmptyString_CopiesString(string input)
        {
            // Arrange
            var sourceMock = new Mock<ISource>();
            var destinationMock = new Mock<IDestination>();

            var index = -1;
            sourceMock.Setup(x => x.GetChar()).Returns(() =>
            {
                index++;
                return index < input.Length ? input[index] : '\n';
            });

            Copier copier = new Copier(destinationMock.Object, sourceMock.Object);

            // Act
            copier.Copy();

            // Assert
            for (int i = 0; i < input.Length; i++)
            {
                char expectedChar = input[i];
                destinationMock.Verify(x => x.SetChar(expectedChar), Times.Once);
            }
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Copy_NoNewline_ThrowsArgumentException()
        {
            // Arrange
            var sourceMock = new Mock<ISource>();
            sourceMock.Setup(x => x.GetChar()).Returns('a');

            var destinationMock = new Mock<IDestination>();
            Copier copier = new Copier(destinationMock.Object, sourceMock.Object);

            // Act
            copier.Copy();

            // No Assert needed for negative tests
        }



        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void Copy_NullSource_ThrowsArgumentNullException()
        {
            // Arrange
            var destinationMock = new Mock<IDestination>();

            // Act
            Copier copier = new Copier(destinationMock.Object, null);

            // No Assert needed for negative tests
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void Copy_NullDestination_ThrowsArgumentNullException()
        {
            // Arrange
            var sourceMock = new Mock<ISource>();

            // Act
            Copier copier = new Copier(null, sourceMock.Object);

            // No Assert needed for negative tests
        }

        [TestMethod]
        public void Copy_CallsSourceGetCharAtLeastOnce()
        {
            // Arrange
            var sourceMock = new Mock<ISource>();
            var destinationMock = new Mock<IDestination>();

            sourceMock.SetupSequence(x => x.GetChar())
                .Returns('a')
                .Returns('\n');

            Copier copier = new Copier(destinationMock.Object, sourceMock.Object);

            // Act
            copier.Copy();

            // Assert
            sourceMock.Verify(x => x.GetChar(), Times.AtLeastOnce);
        }


        [TestMethod]

        public void Copy_CallsDestinationSetCharAtLeastOnce()
        {

            // Arrange
            var sourceMock = new Mock<ISource>();
            var destinationMock = new Mock<IDestination>();
            sourceMock.SetupSequence(x => x.GetChar())
            .Returns('a')
            .Returns('\n');



            Copier copier = new Copier(destinationMock.Object, sourceMock.Object);

            // Act
            copier.Copy();

            // Assert
            destinationMock.Verify(x => x.SetChar(It.IsAny<char>()), Times.AtLeastOnce);
        }

        // Additional test
        [TestMethod]
        public void Copy_WhenCalled_CallsSetCharForEachCharacterInSource()
        {
            // Arrange
            string input = "test";
            var sourceMock = new Mock<ISource>();
            var destinationMock = new Mock<IDestination>();

            var index = -1;
            sourceMock.Setup(x => x.GetChar()).Returns(() =>
            {
                index++;
                return index < input.Length ? input[index] : '\n';
            });

            Copier copier = new Copier(destinationMock.Object, sourceMock.Object);

            // Act
            copier.Copy();

            // Assert
            destinationMock.Verify(x => x.SetChar(It.IsAny<char>()), Times.Exactly(input.Length));
        }

        [TestMethod]
        public void Copy_StringWithNewline_CopiesStringWithoutNewline()
        {
            // Arrange
            string input = "test\n";
            var sourceMock = new Mock<ISource>();
            var destinationMock = new Mock<IDestination>();

            var index = -1;
            sourceMock.Setup(x => x.GetChar()).Returns(() =>
            {
                index++;
                return index < input.Length ? input[index] : '\n';
            });

            Copier copier = new Copier(destinationMock.Object, sourceMock.Object);

            // Act
            copier.Copy();

            // Assert
            for (int i = 0; i < input.Length - 1; i++) // Exclude newline
            {
                char expectedChar = input[i];
                destinationMock.Verify(x => x.SetChar(expectedChar), Times.Once);
            }
            destinationMock.Verify(x => x.SetChar('\n'), Times.Never);
        }


        [TestMethod]
        public void Copy_StringWithSpecialCharacters_CopiesString()
        {
            // Arrange
            string input = "!@#$%^&*()_+";
            var sourceMock = new Mock<ISource>();
            var destinationMock = new Mock<IDestination>();

            var index = -1;
            sourceMock.Setup(x => x.GetChar()).Returns(() =>
            {
                index++;
                return index < input.Length ? input[index] : '\n';
            });

            Copier copier = new Copier(destinationMock.Object, sourceMock.Object);

            // Act
            copier.Copy();

            // Assert
            for (int i = 0; i < input.Length; i++)
            {
                char expectedChar = input[i];
                destinationMock.Verify(x => x.SetChar(expectedChar), Times.Once);
            }
        }


    }



}