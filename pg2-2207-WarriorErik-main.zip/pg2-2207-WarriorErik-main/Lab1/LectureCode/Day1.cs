﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LectureCode
{
    internal static class Day1
    {
        public static void Run()
        {


            






        }



        public static void PrintMessage()
        {



            Console.WriteLine("I am Awesome :)!!! ");







        }




    }
}
