﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LectureCode
{
    internal static class Day7
    {
        public static void Run()
        {

        }
    }
}
