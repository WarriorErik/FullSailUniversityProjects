using FooClassLibrary;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FooClassLibraryTests
{
    [TestClass]
    public class FooTests
    {
        [TestMethod]
        public void Constructor_Default_InitializesEmptyNameAndZeroValue()
        {
            // Arrange & Act
            Foo foo = new Foo();

            // Assert
            Assert.AreEqual(string.Empty, foo.Name);
            Assert.AreEqual(0, foo.Value);
        }




        [TestMethod]
        public void Constructor_WithNameAndValue_InitializesProperties()
        {
            // Arrange & Act
            Foo foo = new Foo("TestName", 50);

            // Assert
            Assert.AreEqual("TestName", foo.Name);
            Assert.AreEqual(50, foo.Value);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void Constructor_WithNameNull_ThrowsNullReferenceException()
        {
            // Arrange & Act
            Foo fooTwo = new Foo(null, 50);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Constructor_WithNameInvalidCharacter_ThrowsFormatException()
        {
            // Arrange & Act
            Foo foo = new Foo("TestName!", 50);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_WithValueBelowMinValue_ThrowsArgumentOutOfRangeException()
        {
            // Arrange & Act
            Foo foo = new Foo("TestName", -1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_WithValueAboveMaxValue_ThrowsArgumentOutOfRangeException()
        {
            // Arrange & Act
            Foo foo = new Foo("TestName", 101);
        }

        [TestMethod]
        public void CopyConstructor_CopiesPropertiesFromSource()
        {
            // Arrange
            Foo original = new Foo("TestName", 50);

            // Act
            Foo copy = new Foo(original);

            // Assert
            Assert.AreEqual(original.Name, copy.Name);
            Assert.AreEqual(original.Value, copy.Value);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void CopyConstructor_SourceFooNull_ThrowsNullReferenceException()
        {
            // Arrange & Act
            Foo copy = new Foo(null);
        }

        [TestMethod]
        public void Name_SetValidName_SetsName()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.Name = "TestName";

            // Assert
            Assert.AreEqual("TestName", foo.Name);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void Name_SetNull_ThrowsNullReferenceException()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.Name = null;
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Name_SetInvalidCharacter_ThrowsFormatException()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.Name = "TestName!";
        }

        [TestMethod]
        public void Value_SetValidValue_SetsValue()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.Value = 50;

            // Assert
            Assert.AreEqual(50, foo.Value);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Value_SetValueBelowMinValue_ThrowsArgumentOutOfRangeException()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.Value = -1;
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Value_SetValueAboveMaxValue_ThrowsArgumentOutOfRangeException()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.Value = 101;
        }



        [TestMethod]
        public void Parse_ValidNameValueString_ReturnsFoo()
        {
            // Arrange
            string input = "TestName,50";

            // Act
            Foo foo = Foo.Parse(input);

            // Assert
            Assert.AreEqual("TestName", foo.Name);
            Assert.AreEqual(50, foo.Value);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Parse_InvalidFormat_ThrowsFormatException()
        {
            // Arrange
            string input = "TestName-50";

            // Act
            Foo foo = Foo.Parse(input);
        }

        [TestMethod]
        public void AssignTrimmedValue_ValueBelowMinValue_SetsMinValue()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.AssignTrimmedValue(-1);

            // Assert
            Assert.AreEqual(Foo.MinValue, foo.Value);
        }

        [TestMethod]
        public void AssignTrimmedValue_ValueAboveMaxValue_SetsMaxValue()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.AssignTrimmedValue(101);

            // Assert
            Assert.AreEqual(Foo.MaxValue, foo.Value);
        }

        [TestMethod]
        public void AssignTrimmedValue_ValueWithinRange_SetsValue()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.AssignTrimmedValue(50);

            // Assert
            Assert.AreEqual(50, foo.Value);
        }


        [TestMethod]
        public void Constructor_WithNameEmptyString_SetsEmptyName()
        {
            // Arrange & Act
            Foo foo = new Foo("", 50);

            // Assert
            Assert.AreEqual("", foo.Name);
        }

        [TestMethod]
        public void Value_SetValueAtMinValue_SetsValue()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.Value = Foo.MinValue;

            // Assert
            Assert.AreEqual(Foo.MinValue, foo.Value);
        }

        [TestMethod]
        public void Value_SetValueAtMaxValue_SetsValue()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.Value = Foo.MaxValue;

            // Assert
            Assert.AreEqual(Foo.MaxValue, foo.Value);
        }

        [TestMethod]
        public void Parse_ValidNameValueStringWithMaxValue_ReturnsFoo()
        {
            // Arrange
            string input = "TestName,100";

            // Act
            Foo foo = Foo.Parse(input);

            // Assert
            Assert.AreEqual("TestName", foo.Name);
            Assert.AreEqual(100, foo.Value);
        }

        [TestMethod]
        public void Parse_ValidNameValueStringWithMinValue_ReturnsFoo()
        {
            // Arrange
            string input = "TestName,0";

            // Act
            Foo foo = Foo.Parse(input);

            // Assert
            Assert.AreEqual("TestName", foo.Name);
            Assert.AreEqual(0, foo.Value);
        }

        [TestMethod]
        public void AssignTrimmedValue_ValueAtMinValue_SetsValue()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.AssignTrimmedValue(Foo.MinValue);

            // Assert
            Assert.AreEqual(Foo.MinValue, foo.Value);
        }

        [TestMethod]
        public void AssignTrimmedValue_ValueAtMaxValue_SetsValue()
        {
            // Arrange
            Foo foo = new Foo();

            // Act
            foo.AssignTrimmedValue(Foo.MaxValue);

            // Assert
            Assert.AreEqual(Foo.MaxValue, foo.Value);
        }

        [TestMethod]
        public void Parse_ValidNameValueStringWithOnlyOneCharacter_ReturnsFoo()
        {
            // Arrange
            string input = "A,50";

            // Act
            Foo foo = Foo.Parse(input);

            // Assert
            Assert.AreEqual("A", foo.Name);
            Assert.AreEqual(50, foo.Value);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Parse_InvalidNameValueStringWithNumberInName_ThrowsFormatException()
        {
            // Arrange
            string input = "Test1Name,50";

            // Act
            Foo foo = Foo.Parse(input);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Parse_InvalidNameValueStringWithSpecialCharacterInName_ThrowsFormatException()
        {
            // Arrange
            string input = "Test_Name,50";

            // Act
            Foo foo = Foo.Parse(input);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Parse_InvalidNameValueStringWithSpaceInName_ThrowsFormatException()
        {
            // Arrange
            string input = "Test Name,50";

            // Act
            Foo foo = Foo.Parse(input);
        }
    }
}