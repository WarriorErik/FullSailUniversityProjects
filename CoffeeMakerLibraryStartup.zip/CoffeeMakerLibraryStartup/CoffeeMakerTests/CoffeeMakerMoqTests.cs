﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CoffeeMakerLibrary;
using Moq;

namespace CoffeeMakerTests
{
    [TestClass]
    public class CoffeeMakerMoqTests
    {
        [TestMethod]
        public void MOQTest1()
        {
            // ARRANGE
            Mock<IContainer> waterContainer = new Mock<IContainer>();
            Mock<IContainer> coffeeContainer = new Mock<IContainer>();
            ICoffeeMaker coffeeMaker = new CoffeeMaker(waterContainer.Object, coffeeContainer.Object);


            // Call Fill() to fill the coffee maker.
            coffeeMaker.Fill();

            // ACT
            // Call MakeCoffee() requesting a Grande(3).
            coffeeMaker.MakeCoffee(Portion.Grande);

            // ASSERT
            // Assert that the coffee volume is now 7 using the CoffeeVolume property.
            // Assert that the water volume is now 7 using the WaterVolume property.
            waterContainer.Verify(c => c.Fill(), Times.Once);
            coffeeContainer.Verify(c => c.Fill(), Times.Once);
            waterContainer.Verify(c => c.DispensePortion(Portion.Grande), Times.Once);
            coffeeContainer.Verify(c => c.DispensePortion(Portion.Grande), Times.Once);
        }

        [TestMethod]
        public void MOQTest2()
        {


            // ARRANGE
            Mock<IContainer> waterContainer = new Mock<IContainer>();
            Mock<IContainer> coffeeContainer = new Mock<IContainer>();
            ICoffeeMaker coffeeMaker = new CoffeeMaker(waterContainer.Object, coffeeContainer.Object);

            // Set the water to 6 using the WaterVolume property.
            waterContainer.Setup(c => c.GetVolume()).Returns(6);

            // Set the water to 8 using the WaterVolume property.
            coffeeContainer.Setup(c => c.GetVolume()).Returns(8);
          

            // ACT 
            // MakeCoffee() requesting a Tall(2).
            coffeeMaker.MakeCoffee(Portion.Tall);

            // ASSERT
            // Assert that the coffee volume is now 6 using the CoffeeVolume property.
            // Assert that the water volume is now 4 using the WaterVolume property.
            coffeeContainer.Verify(c => c.DispensePortion(Portion.Tall), Times.Once);
            waterContainer.Verify(c => c.DispensePortion(Portion.Tall), Times.Once);
        }

        [TestMethod]
        public void MOQTest3()
        {
            // ARRANGE
            Mock<IContainer> waterContainer = new Mock<IContainer>();
            Mock<IContainer> coffeeContainer = new Mock<IContainer>();
            ICoffeeMaker coffeeMaker = new CoffeeMaker(waterContainer.Object, coffeeContainer.Object);

            // Set the coffee to 5 using the CoffeeVolume property.
            coffeeMaker.CoffeeVolume = 5;

            // Set the water to 5 using the WaterVolume property. 
            coffeeMaker.WaterVolume = 5;

            // ACT
            // Clean() the coffee maker.
            coffeeMaker.Clean();

            // ASSERT
            // Assert that the coffee volume is now 0 using the IsEmpty property.
            waterContainer.Verify(c => c.Empty(), Times.Once);
            coffeeContainer.Verify(c => c.Empty(), Times.Once);
        }

        [TestMethod]
        public void MOQTest4()
        {

            // ARRANGE
            Mock<IContainer> waterContainer = new Mock<IContainer>();
            Mock<IContainer> coffeeContainer = new Mock<IContainer>();
            ICoffeeMaker coffeeMaker = new CoffeeMaker(waterContainer.Object, coffeeContainer.Object);

            waterContainer.Setup(c => c.GetVolume()).Returns(2);
            coffeeContainer.Setup(c => c.GetVolume()).Returns(4);
            waterContainer.Setup(c => c.DispensePortion(It.IsAny<int>()))
                          .Callback((int portion) =>
                          {
                              if (portion > waterContainer.Object.GetVolume())
                              {
                                  throw new InvalidOperationException();
                              }
                          });

            // ACT & ASSERT
            Assert.ThrowsException<InvalidOperationException>(() => coffeeMaker.MakeCoffee(Portion.Grande));
        }


        [TestMethod]
        public void MOQTest5()
        {
            // ARRANGE
            Mock<IContainer> waterContainer = new Mock<IContainer>();
            Mock<IContainer> coffeeContainer = new Mock<IContainer>();
            ICoffeeMaker coffeeMaker = new CoffeeMaker(waterContainer.Object, coffeeContainer.Object);

            // ACT
            // Clean() the CoffeeMaker.
            coffeeMaker.Clean();

            // VERIFY
            // Verify that cleaning the CoffeeMaker calls the water containers Clean() once.
            // Verify that cleaning the CoffeeMaker calls the coffee containers Clean() twice.
            coffeeContainer.Verify(c => c.Clean(), Times.Exactly(2));
        }

    }
}
