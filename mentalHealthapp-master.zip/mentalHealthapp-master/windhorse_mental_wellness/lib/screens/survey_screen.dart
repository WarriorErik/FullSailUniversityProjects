import 'dart:math';
import 'package:flutter/material.dart';

class SurveyScreen extends StatefulWidget {
  @override
  _SurveyScreenState createState() => _SurveyScreenState();
}

class _SurveyScreenState extends State<SurveyScreen> {
  int _questionIndex = 0;
  double _currentRating = 0;
  double _totalScore = 0;

  final List<String> _questions = [
    'Question 1: On a scale from 0 to 10, Do you often feel down, depressed, or hopeless? ',
    'Question 2: On a scale from 0 to 10, Do you have little interest or pleasure in doing things?',
    'Question 3: On a scale from 0 to 10, Do you often feel tired or have little energy?',
    'Question 4: On a scale from 0 to 10, Do you often have trouble falling asleep, staying asleep, or sleeping too much?',
    'Question 5: On a scale from 0 to 10, Do you often have poor appetite or overeat?',
    'Question 6: On a scale from 0 to 10, Do you often feel bad about yourself, or that you are a failure or have let yourself or your family down?',
    'Question 7: On a scale from 0 to 10, Do you often have trouble concentrating on things, such as reading or watching television?'
  ];

  final List<String> _motivationalQuotes = [
    "Don't let yesterday take up too much of today.",
    "Believe you can and you're halfway there.",
    "The only limit to our realization of tomorrow will be our doubts of today."
  ];

  final List<String> _therapyAdvice = [
    "Remember to take some time for self-care today.",
    "Try mindfulness exercises, such as focused breathing or meditation.",
    "Seek support from friends, family, or a mental health professional."
  ];

  void _answerQuestion() {
    if (_questionIndex < _questions.length - 1) {
      setState(() {
        _totalScore += _currentRating;
        _questionIndex = _questionIndex + 1;
        _currentRating = 0;
      });
    } else {
      _endOfQuestionnaire();
    }
  }

  void _previousQuestion() {
    if (_questionIndex > 0) {
      setState(() {
        _questionIndex = _questionIndex - 1;
        _totalScore -= _currentRating;
        _currentRating = 0;
      });
    }
  }

  void _endOfQuestionnaire() {
    setState(() {
      _totalScore += _currentRating; // Add the score of the last question
      _currentRating = 0;
    });

    String advice = _totalScore < 37
        ? 'Motivational Quote: ${_motivationalQuotes[Random().nextInt(_motivationalQuotes.length)]}\n\n'
          'Advice: ${_therapyAdvice[Random().nextInt(_therapyAdvice.length)]}\n\n'
          'Please consider discussing your results with a healthcare provider.'
        : '';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Survey Completed'),
          content: Text('Thank you for completing the mental health survey! Your score is ${_totalScore.round()}.\n\n$advice'),
          actions: [
            TextButton(
              child: Text('Close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mental Health Screening'),
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                _questions[_questionIndex],
                style: const TextStyle(fontSize: 28),
                textAlign: TextAlign.center,
              ),
            ),
            Text('0 is the worst, 10 is the best emotional state.', style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Slider(
                value: _currentRating,
                min: 0,
                max: 10,
                divisions: 10,
                label: _currentRating.round().toString(),
                onChanged: (value) {
                  setState(() {
                    _currentRating = value;
                  });
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  child: const Text('Previous Question'),
                  onPressed: _questionIndex > 0 ? _previousQuestion : null, // Disable button if we're at the first question
                ),
                ElevatedButton(
                  child: const Text('Next Question'),
                  onPressed: _questionIndex < _questions.length - 1 ? _answerQuestion : null, // Disable button if we're at the last question
                ),
                ElevatedButton(
                  child: const Text('Submit'),
                  onPressed: _questionIndex == _questions.length - 1 ? _endOfQuestionnaire : null, // Enable submit button only on the last question
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
