﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LectureCode
{
    public static class Lectures
    {
        static void Main(string[] args)
        {
            Day7.Run();
            Day8.Run();
            Day9.Run();
        }
    }
}
