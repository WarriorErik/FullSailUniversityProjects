#pragma once

class BaseObject
{
public:

	ConsoleColor color = White;			
	int x_position = 0;
	int y_position = 0;
	char visage = '.';
	//note to self: contains returns true if x and y are within the brick
	virtual void Draw() const;
};