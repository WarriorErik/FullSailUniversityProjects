import 'package:flutter/material.dart';
import 'package:windhorse_mental_wellness/screens/home_screen.dart';
import 'package:windhorse_mental_wellness/screens/login_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Solution Focused Brief Therapy App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginScreen(), // Setting LoginScreen as the first screen to display
        '/home': (context) => HomeScreen(), // Named route for the HomeScreen
      },
    );
  }
}
